package com.example.myvideophone;

/*import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

public class VisitLogActivity extends AppCompatActivity {
    ListView list;

    ArrayList <rowData> dataList;
    //ArrayList<Object> arr = new ArrayList<>();
    String[] visit_dates;
    private String json_string;
    //ImageView imageView;
    rowData data;
    CustomList adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        adapter = new CustomList(VisitLogActivity.this);
        GetItem getItem = new GetItem();
        getItem.execute();
        dataList = new ArrayList<>();

        dataList.add(new rowData("0000-00-00 00:00:00","http://0.0.0.0/*.php"));

        //downloadJSON("http://192.168.219.107/test.php");

        /*dataList.add(new rowData("벤츠 뉴 S클래스 S350", R.drawable.car1, "일진선", "050-1111-1111", 600, "2017/10","13km/l", "검정", "자동", "3000cc", "7000km","디젤", "무

        visit_dates = new String[dataList.size()];
        for (int i = 0; i < dataList.size(); i++){
            visit_dates[i] = dataList.get(i).visit_date;
            Log.d("jinjin","zzzz"+visit_dates[i]);
        }

        //adapter = new CustomList(VisitLogActivity.this);

        list = (ListView)findViewById(R.id.list);
        if (list==null){
            Log.d("jinjin","check1");
        }
        if (adapter == null) {
            Log.d("jinjin","check2");
        }
        list.setAdapter(adapter);
    }

    public class CustomList extends ArrayAdapter<String> {
        private final Activity context;

        public CustomList(Activity context){
            super(context,R.layout.listitem, visit_dates);
            this.context = context;
        }

        @Override
        public View getView(int position, View view, ViewGroup parent){
            LayoutInflater inflater = context.getLayoutInflater();
            View rowView = inflater.inflate(R.layout.listitem, null, true);
            ImageView imageView = (ImageView)rowView.findViewById(R.id.image);
            TextView visit_date = (TextView)rowView.findViewById(R.id.visit_date);
            visit_date.setText(dataList.get(position).visit_date);
            //imageView = (ImageView)findViewById(R.id.imageView);
            //Glide.with(imageView.getContext()).load(dataList.get(position).image_url).into(imageView);
            imageView.setImageResource(R.drawable.ic_launcher_foreground);
            //imageView.setImageResource(dataList.get(position).image);
            return rowView;
        }
    }


    //private void downloadJSON(final String urlWebService) {


    class GetItem extends AsyncTask<String, Void, String> {

        //private String IP = "220.69.208.235";
        private String IP = "192.168.219.107";
        private String PHP = "test.php";

        @Override
        protected String doInBackground(String... strings) {
            String data = null;
            //StringBuffer param = new StringBuffer();
            //param.append("item_num").append("=").append(strings[0]);

            //Log.d("junjun params", param.toString());
            try {
                // 서버 연결
                URL server = new URL("http://" + IP + "/" + PHP);

                //====[1] : urlConnection 설정====
                //해당 주소로 접속하고, 단일 HTTP접속을 하기위해 캐스트함
                HttpURLConnection urlConnection = (HttpURLConnection) server.openConnection();
                urlConnection.setConnectTimeout(1000);
                urlConnection.setReadTimeout(3000);
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);
                urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");


                //====[3] : 연결 요청 확인====
                if (urlConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    //InputStream is = new BufferedInputStream(urlConnection.getInputStream());
                    BufferedReader br = new BufferedReader(new InputStreamReader(urlConnection.getInputStream(), "UTF-8"));
                    StringBuffer sb = new StringBuffer();
                    String line = null;
                    while ((line = br.readLine()) != null) {
                        sb.append(line);
                    }
                    br.close();
                    data = sb.toString();
                    Log.d("jinjin: ", data);
                    urlConnection.disconnect();
                } else
                    Log.e("jinjin", "연결 실패");
                return data.trim();

            } catch (Exception e) {
                return new String("Exception" + e.getMessage());
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result == null)
                ;
            else {
                json_string = result;
                Log.d("jinjin json", json_string);
                create_item();
            }
        }
    }

    @SuppressLint("CheckResult")
    private void create_item(){ //json 가공
        String TAG_JSON = "item";
        String TAG_DATE = "visit_date";
        String TAG_IMG = "image";
        try {
            JSONObject jsonObject = new JSONObject(json_string);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);
            jsonObject = jsonArray.getJSONObject(0);

            String date = jsonObject.getString(TAG_DATE);
            String img_url = jsonObject.getString(TAG_IMG);

            data = new rowData(date, img_url);
            dataList.add(data);
            adapter.notifyDataSetChanged();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}*/

import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class VisitLogActivity extends AppCompatActivity {

    private static String IP_ADDRESS = "192.168.219.107";
    private static String TAG = "phptest";

    // private EditText mEditTextName;
    // private EditText mEditTextCountry;
    //private TextView mTextViewResult;
    private ArrayList<rowData> mArrayList;
    private CustomList mAdapter;
    //private RecyclerView mRecyclerView;
    ListView mListView;
    String[] titles;
    //  private EditText mEditTextSearchKeyword;
    private String mJsonString;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visitlog);

        //mTextViewResult = (TextView)findViewById(R.id.textView_main_result);
        titles = new String[20];

        mAdapter = new CustomList(VisitLogActivity.this);
        mListView = (ListView)findViewById(R.id.list);
        mListView.setAdapter(mAdapter);
        //mListView.setLayoutManager(new LinearLayoutManager(this));
        //mTextViewResult.setMovementMethod(new ScrollingMovementMethod());



        mArrayList = new ArrayList<>();
        GetData task = new GetData();
        task.execute( "http://" + IP_ADDRESS + "/test.php", "");
        //mAdapter = new UsersAdapter(this, mArrayList);
        //mListView.setAdapter(mAdapter);


        //Button button_all = (Button) findViewById(R.id.button_main_all);
        /*button_all.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                mArrayList.clear();
                mAdapter.notifyDataSetChanged();

                GetData task = new GetData();
                task.execute( "http://" + IP_ADDRESS + "/test.php", "");
            }
        });*/

    }



    private class GetData extends AsyncTask<String, Void, String>{

        ProgressDialog progressDialog;
        String errorString = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(VisitLogActivity.this,
                    "Please Wait", null, true, true);
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            //mTextViewResult.setText(result);
            Log.d(TAG, "response - " + result);

            if (result == null){
                Log.d("jinjin","there's nothig");
                //mTextViewResult.setText(errorString);
            }
            else {

                mJsonString = result;
                showResult();
            }
            //showResult();
        }


        @Override
        protected String doInBackground(String... params) {

            String serverURL = params[0];
            String postParameters = params[1];


            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }

                bufferedReader.close();

                return sb.toString().trim();


            } catch (Exception e) {

                Log.d(TAG, "GetData : Error ", e);
                errorString = e.toString();

                return null;
            }

        }
    }


    private void showResult(){

        String TAG_JSON="result";
        String TAG_DATE = "visit_date";
        String TAG_IMAGE = "image";
        String TAG_COUNTRY ="country";


        try {
            JSONObject jsonObject = new JSONObject(mJsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            for(int i=0;i<jsonArray.length();i++){

                JSONObject item = jsonArray.getJSONObject(i);

                String visit_date = item.getString(TAG_DATE);
                String image = "http://"+IP_ADDRESS+"/"+ item.getString(TAG_IMAGE);
                //String country = item.getString(TAG_COUNTRY);
                Log.d("jinjin",item.getString(TAG_DATE) + "sss" + image+"sss");

                rowData DataList = new rowData(visit_date,image);

                //personalData.visit_date = visit_date;
                //personalData.setMember_name(name);
                //personalData.setMember_country(country);

                mArrayList.add(DataList);
                Log.d("jinjin",mArrayList.size()+"length...!");

                //titles = new String[mArrayList.size()];
                for (int j = 0; j < mArrayList.size(); j++){
                    titles[j] = j+"";
                }
/*                LayoutInflater inflater = VisitLogActivity.this.getLayoutInflater();
                View rowView = inflater.inflate(R.layout.listitem, null, true);
                ImageView mImageView = (ImageView)rowView.findViewById(R.id.image);
                TextView mTextViews = (TextView)rowView.findViewById(R.id.visit_date);
                mTextViews.setText(mArrayList.get(mArrayList.size()-1).visit_date);
                //image.setImageResource(mArrayList.get(position).image);
                Glide.with(mImageView.getContext()).load(mArrayList.get(mArrayList.size()-1).image_url).into(mImageView);*/
//                mArrayList.notify();
                mAdapter.notifyDataSetChanged();
            }



        } catch (JSONException e) {

            Log.d(TAG, "showResult : ", e);
        }

    }
    public class CustomList extends ArrayAdapter<String> {
        private final Activity context;

        public CustomList(Activity context){
            super(context,R.layout.listitem, titles);
            this.context = context;
        }

        @Override
        public View getView(int position, View view, ViewGroup parent){
           // Log.d("jinjin","cddkcskajkldjslk");
            LayoutInflater inflater = context.getLayoutInflater();
            View rowView = inflater.inflate(R.layout.listitem, null, true);
            ImageView image = (ImageView)rowView.findViewById(R.id.image);
            TextView visit_date = (TextView)rowView.findViewById(R.id.visit_date);
            /*for (int i =0; i< mArrayList.size(); i++) {
                if (visit_date.getText()=="") {
                    visit_date.setText(mArrayList.get(i).visit_date);
                    //image.setImageResource(mArrayList.get(position).image);
                    Glide.with(image.getContext()).load(mArrayList.get(i).image_url).into(image);
                    //break;
                }
            }*/
            if (position<mArrayList.size()){
                visit_date.setText(mArrayList.get(position).visit_date);
                Glide.with(image.getContext()).load(mArrayList.get(position).image_url).into(image);
            }

            return rowView;
        }
    }

}
