package com.example.myvideophone;

public class rowData {
    String visit_date = "";
    String image_url = "";

    public rowData(String visit_date, String image_url){
        this.visit_date = visit_date;
        this.image_url = image_url;
    }
}
